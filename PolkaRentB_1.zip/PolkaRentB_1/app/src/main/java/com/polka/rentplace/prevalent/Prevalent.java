package com.polka.rentplace.prevalent;

import com.polka.rentplace.model.Users;

public class Prevalent {

    public static Users currentOnlineUser;

    public static final String UserPhoneKey = "UserPhone";
    public static final String UserPasswordKey = "UserPassword";

}
