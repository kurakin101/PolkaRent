package com.polka.rentplace.Interface;

import android.view.View;

public interface ItemClickListerner {

    void  onClick(View view, int position, boolean isLongClick);

}
