package com.polka.rentplace.model;

public class Face {
    public static int faceResult = 0;
}
